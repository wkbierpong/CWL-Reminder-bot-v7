function cleanDiscordName(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  if (/^<@!?\d+>$/.test(text)) return "";
  if (/^\d{16,22}$/.test(text)) return "";
  return text.replace(/^@/, "");
}

function buildReminderMessage(template, member, user) {
  const username =
    cleanDiscordName(member.discord) ||
    user?.globalName ||
    user?.username ||
    member.playerName ||
    "clangenoot";

  return template
    .replaceAll("[Username]", username)
    .replaceAll("[PlayerName]", member.playerName || username)
    .replaceAll("[PlayerTag]", member.playerTag || "");
}

module.exports = {
  buildReminderMessage
};
